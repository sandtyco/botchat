-- phpMyAdmin SQL Dump
-- version 3.1.3.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 08, 2014 at 10:33 AM
-- Server version: 5.1.33
-- PHP Version: 5.2.9

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `chatbot`
--

-- --------------------------------------------------------

--
-- Table structure for table `pending`
--

CREATE TABLE IF NOT EXISTS `pending` (
  `trigger` text COLLATE latin1_general_ci NOT NULL,
  `reply` text COLLATE latin1_general_ci NOT NULL,
  `rnumber` tinyint(4) unsigned NOT NULL DEFAULT '0',
  `rid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`rid`),
  FULLTEXT KEY `trigger` (`trigger`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=7 ;

--
-- Dumping data for table `pending`
--

INSERT INTO `pending` (`trigger`, `reply`, `rnumber`, `rid`) VALUES
('sudah terhubung', 'hali', 1, 1),
('hali', 'halo', 1, 2),
('ya ada yang bisa kami bantu', 'malam', 1, 3),
('selamat malam', 'boleh tanya', 1, 4),
('baik silahkan apa ada yang bisa kami bantu', 'harga laptop', 1, 5),
('untuk laptop spesifikasi apa', 'harga hp', 1, 6);

-- --------------------------------------------------------

--
-- Table structure for table `replies`
--

CREATE TABLE IF NOT EXISTS `replies` (
  `trigger` text COLLATE latin1_general_ci NOT NULL,
  `reply` text COLLATE latin1_general_ci NOT NULL,
  `usercontrib` tinyint(4) NOT NULL DEFAULT '0',
  `rid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`rid`),
  FULLTEXT KEY `trigger` (`trigger`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci AUTO_INCREMENT=11 ;

--
-- Dumping data for table `replies`
--

INSERT INTO `replies` (`trigger`, `reply`, `usercontrib`, `rid`) VALUES
('Halo, Hai, Hello, Permisi, Alo', 'Ya, Ada yang bisa kami bantu', 0, 1),
('Siang', 'Selamat Siang...', 0, 2),
('Pagi', 'Selamat Pagi...', 0, 3),
('Sore', 'Selamat Sore...', 0, 4),
('Malam, Malem', 'Selamat Malam...', 0, 5),
('tolongin neh, mau tanya, boleh tanya, help', 'Baik Silahkan..., Apa ada yang bisa kami bantu', 0, 6),
('Harga Komputer', 'Untuk komputer spesifikasi apa..?', 0, 7),
('harga laptop', 'Untuk laptop spesifikasi apa..?', 0, 8),
('harga tablet', 'Untuk tablet spesifikasi apa..?', 0, 9),
('apa saja yang ada, dijual, baru, bekas, barang', 'Kami menyediakan perangkat elektronik, gadget, mobile aksesoris teknologi, dan sebagainya.', 0, 10);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `nama`, `email`) VALUES
(1, 'admin', 'admin', 'admin', 'admin@admin.com'),
(3, 'meilita', 'memey', 'Meilita Rahayu', 'meilitarahayu@gmail.com');
