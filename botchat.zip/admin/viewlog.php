<?php
session_start();
include ("koneksi.php");
if ($_SESSION['username'] && $_SESSION['password']){
$sql = mysql_query("SELECT * FROM user WHERE username='".$_SESSION['username']."' AND password='".$_SESSION['password']."'");
$hasil = mysql_fetch_assoc($sql);
	}else{
	header("location:login.php");
	}
?> 

<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="author" content="">
		<link rel="shortcut icon" href="./ico/favicon.ico">

		<title>Contoh Latihan Desain</title>
		
		<script src="../js/jquery.js" type="text/javascript"></script>
        <script src="../js/jquery.dataTables.js" type="text/javascript"></script>
        <style type="text/css">
            @import "../css/demo_table_jui.css";
            @import "../themes/ui-lightness/jquery-ui-1.8.4.custom.css";
        </style>
        <script type="text/javascript" charset="utf-8">
            $(document).ready(function(){
                $('#datatables').dataTable({
                    "sPaginationType":"full_numbers",
                    "aaSorting":[[2, "desc"]],
                    "bJQueryUI":true
                });
            })
        </script>

		<!-- Bootstrap core CSS -->
		<link href="../css/bootstrap.css" rel="stylesheet">
		<link href="../css3/bootstrap.min.css" rel="stylesheet">

		<!-- Custom styles for this template -->
		<link href="../css/justified-nav.css" rel="stylesheet">

		<!-- Just for debugging purposes. Don't actually copy this line! -->
		<!--[if lt IE 9]><script src="../js/ie8-responsive-file-warning.js"></script><![endif]-->

		<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
		<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
	</head>
	
	<body>
		<div class="container">
			<div class="row-fluid"><!--Container Navigasi-->
				<div class="masthead"><!--bagian Navigasi-->
					<div class="row-fluid">
						<div class="span9" style="margin-top: 50px;">
							<h1 class="text-muted"><b><? echo "Administrator Mey-Chatt"; ?></b></h1>
						</div>
						<div class="span3" align="right"><img src="../img/bot-c (4).jpg" alt="bot1" name="bot1" width="200px" height="200px"></img></div>
					</div>
					<hr>
					<div class="row-fluid">
						<div class="span8">
							<h5><?php echo "Anda login sebagai user <b style='color:blue;'>".$hasil['nama']."</b>"; ?></h5>
						</div>
						<div class="span4" align="right">
							<a href="index.php" class="btn btn-primary disable" type="button">Home</a>
							<a href="../index.php" class="btn btn-primary disable" type="button">Aplikasi</a>
							<a href="logout.php" class="btn btn-primary disable" type="button">Logout</a>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<div class="container">
			<div class="row-fluid">
				<div class="span3">
					<div class="well">
						<a href="tambahdata.php" class="btn btn-block btn-primary disable" type="button">Tambah Q/A</a>
						<a href="editdata.php" class="btn btn-block btn-primary disable" type="button">Edit Q/A</a>
						<a href="viewlog.php" class="btn btn-block btn-primary disable" type="button">Lihat Log Q/A</a>
						<hr>
						<a href="daftar.php" class="btn btn-block btn-primary disable" type="button">Pengguna Baru</a>
					</div>
					<div>
						<img src="../img/bot-c (2).png" alt="bot1" name="bot1" width="300px" height="300px"></img>
					</div>
				</div>
				<div class="span9 well"><!-- sebelah sini yang di ubah ketika membuat halaman baru -->
					<h4>LOG PERCAKAPAN</h4>
					<p align="justify">
					Berikut adalah histori dari yang terbaru hingga paling awal antara User dan BotChatt.
					Log ini akan sangat membantu Anda untuk meng-UPDATE semua pertanyaan yang belum di masukan ke dalam trigger/Q untuk kemudian di masukan kedalam database.
					</p>
						<?php 
						if (!empty($_GET['message']) && $_GET['message'] == 'delete') {
						echo "<script>alert('User berhasil dihapus...!');window.history.go(-1);</script>";
						}
						?>
						<table id="datatables" class="table">
							<thead>
								<tr class="well">
									<td>No.</td>
									<td>Pertanyaan</td>
									<td>Jawaban</td>
									<td>Option</td>
								</tr>
							</thead>
							<tbody>
							<?php 
							$query = mysql_query("SELECT * FROM pending");
									$no = 1;
									while ($data = mysql_fetch_array($query)) {
									?>
										<tr>
											<td><?php echo $no; ?></td>
											<td><?php echo $data['trigger']; ?></td>
											<td><?php echo $data['reply']; ?></td>
											<td>
												<a href="dellog.php?rid=<?php echo $data['rid']; ?>">Hapus</a>
											</td>
										</tr>
									<?php 
									$no++;
									} 
									?>
							</tbody>
						</table>
					<p align="justify">
						<b>Catatan : </b>Hapus data log jika memang sudah tidak digunakan, ini sebagai langkah menghemat Space Database.
					</p>
				</div>
			</div>
			<hr>
			<div class="container" align="center" class="footer">
				<p>&copy; Company 2014 Smart Support By : <a href="mailto:meilitarahayu@gmail.com">Meilita Rahayu</a>.</p>
			</div>
		</div>
		
		<!-- Khusus konten javascript -->
		<!--<script src="../js/jquery-tab.js"></script>-->
		<script src="../js/jquery.js"></script>
		<script src="../js/jquery.dataTables.js"></script>
		<script src="../js/bootstrap-transition.js"></script>
		<script src="../js/bootstrap-alert.js"></script>
		<script src="../js/bootstrap-modal.js"></script>
		<script src="../js/bootstrap-dropdown.js"></script>
		<script src="../js/bootstrap-scrollspy.js"></script>
		<script src="../js/bootstrap-tab.js"></script>
		<script src="../js/bootstrap-tooltip.js"></script>
		<script src="../js/bootstrap-popover.js"></script>
		<script src="../js/bootstrap-button.js"></script>
		<script src="../js/bootstrap-collapse.js"></script>
		<script src="../js/bootstrap-carousel.js"></script>
		<script src="../js/bootstrap-typeahead.js"></script>
	</body>
</html>