<?php 
include('koneksi.php');

$rid = $_GET['rid'];

$query = mysql_query("delete from pending where rid='$rid'") or die(mysql_error());

if ($query) {
	header('location:viewlog.php?message=delete');
}
?>