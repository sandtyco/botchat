<?php
include('koneksi.php');

//tangkap data dari form
$rid = $_POST['rid'];
$trigger = $_POST['trigger'];
$reply = $_POST['reply'];
$usercontrib = $_POST['usercontrib'];

//update data di database sesuai user_id
$query = mysql_query("UPDATE replies SET trigger='$trigger', reply='$reply', usercontrib='$usercontrib' where rid='$rid'") or die(mysql_error());

if ($query) {
	header('location:editdata.php?message=success');
}
?>