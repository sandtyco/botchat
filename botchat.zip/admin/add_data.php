<?php
//panggil file koneksi.php yang telah dibuat
include "koneksi.php"; 
 
//mengambil / menangkap variabel yang dikirim oleh form tambahdata.php
$trigger			=	$_POST['trigger'];
$reply			=	$_POST['reply'];
$usercontrib	=	$_POST['usercontrib'];

//fungsi memasukan data kedalam database
if (!empty($trigger)){
	if (!empty($reply)){
		$sql = mysql_query("SELECT * FROM replies");
		$hasil = mysql_fetch_array($sql);
		mysql_query("INSERT INTO replies VALUES('$trigger','$reply','$usercontrib','')");
		echo "<script>alert('Data pengguna baru telah berhasil dimasukan...!');window.history.go(-1);</script>";
		}
		else{
		echo "<script>alert('Maaf... Data tidak bisa bernilai sama...!');window.history.go(-1);</script>";					
		}
	}
?>