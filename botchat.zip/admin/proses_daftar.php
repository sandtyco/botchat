<?php
include ("koneksi.php");
$nama 		= $_POST['nama'];
$email 		= $_POST['email'];
$username 	= $_POST['username'];
$password1 	= $_POST['password'];
$password2 	= $_POST['ulangi_password'];
if (!empty($nama)){
	if (!empty($email)){
		$sql = mysql_query("SELECT * FROM user WHERE email='".$email."'");
		$hasil = mysql_fetch_array($sql);
		if ($hasil['email'] != $email){		
			if (!empty($username)){
				$sql = mysql_query("SELECT * FROM user WHERE username='".$username."'");
				$hasil = mysql_fetch_array($sql);
				if ($hasil['username'] != $username){		
					if (!empty($password1)){
						if (!empty($password2)){
							if ($password1 == $password2){
								mysql_query("INSERT INTO user VALUES('','".$username."','".$password1."','".$nama."','".$email."')");
								echo "<script>alert('Data pengguna baru telah berhasil dimasukan...!');window.history.go(-1);</script>";
							}else{
								echo "<script>alert('Silahkan ulangi password dengan benar...!');window.history.go(-1);</script>";					
							}
						}else{
							echo "<script>alert('Anda belum mengulangi password...!');window.history.go(-1);</script>";				
						}
					}else{
						echo "<script>alert('Anda belum mengisikan password...!');window.history.go(-1);</script>";			
					}
				}else{
					echo "<script>alert('Username telah ada yang menggunakan...!');window.history.go(-1);</script>";			
				}	
			}else{
				echo "<script>alert('Anda belum mengisikan username...!');window.history.go(-1);</script>";		
			}
		}else{
			echo "<script>alert('Email telah digunakan...!');window.history.go(-1);</script>";			
		}	
	}else{
		echo "<script>alert('Anda belum mengisikan email...!');window.history.go(-1);</script>";	
	} 
}else{
	echo "<script>alert('Anda belum mengisi nama...!');window.history.go(-1);</script>";		
}
?>