<?php
session_start();
if (!$_SESSION['username'] && !$_SESSION['password']){
?>
<html>
    <head>
        <meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="author" content="">
		<link rel="shortcut icon" href="./ico/favicon.ico">

		<title>Form Login Bot Chatt</title>
		
		<script src="../js/jquery.js" type="text/javascript"></script>
        <script src="../js/jquery.dataTables.js" type="text/javascript"></script>
        <style type="text/css">
            @import "../css/demo_table_jui.css";
            @import "../themes/ui-lightness/jquery-ui-1.8.4.custom.css";
        </style>
        <script type="text/javascript" charset="utf-8">
            $(document).ready(function(){
                $('#datatables').dataTable({
                    "sPaginationType":"full_numbers",
                    "aaSorting":[[2, "desc"]],
                    "bJQueryUI":true
                });
            })
        </script>

		<!-- Bootstrap core CSS -->
		<link href="../css/bootstrap.css" rel="stylesheet">
		<link href="../css3/bootstrap.min.css" rel="stylesheet">

		<!-- Custom styles for this template -->
		<link href="../css/justified-nav.css" rel="stylesheet">

		<!-- Just for debugging purposes. Don't actually copy this line! -->
		<!--[if lt IE 9]><script src="../js/ie8-responsive-file-warning.js"></script><![endif]-->

		<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
		<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
    </head>
    <body>
		<div class="container">
			<div class="container" align="center" class="footer">
				<h1>ADMIN CHATT</h1>
			</div>
			<hr>
			<div class="row">
				<div class="span6" align="right">
					<img src="../img/bot-c (1).png" alt="bot1" name="bot1" width="300px" height="300px"></img>
					<p>Silahkan login atau ingin kembali ke <a href="../index.php">Aplikasi</a>.
				</div>
				<div class="span3 well">
					<h4 class="form-signin-heading">Silahkan Login</h4>
					<form class="form-signin" action="proses_login.php" method="POST">
					Username<br />
					<input type="text" name="username" /><br />
					Password<br />
					<input type="password" name="password" /><br /><br />
					<input class="btn btn-primary" type="submit" value="Login" />
					</form>
				</div>
			</div>
			<hr>
			<div class="container" align="center" class="footer">
				<p>&copy; Company 2014 Smart Support By : <a href="mailto:meilitarahayu@gmail.com">Meilita Rahayu</a>.</p>
			</div>
		</div>
    </body>
</html>
<?php
}else{
    header("location:index.php");
}
?>