<?php
session_start();
include ("koneksi.php");
if ($_SESSION['username'] && $_SESSION['password']){
$sql = mysql_query("SELECT * FROM user WHERE username='".$_SESSION['username']."' AND password='".$_SESSION['password']."'");
$hasil = mysql_fetch_assoc($sql);
	}else{
	header("location:login.php");
	}
?> 

<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="">
		<meta name="author" content="">
		<link rel="shortcut icon" href="./ico/favicon.ico">

		<title>Contoh Latihan Desain</title>
		
		<script src="../js/jquery.js" type="text/javascript"></script>
        <script src="../js/jquery.dataTables.js" type="text/javascript"></script>
        <style type="text/css">
            @import "../css/demo_table_jui.css";
            @import "../themes/ui-lightness/jquery-ui-1.8.4.custom.css";
        </style>
        <script type="text/javascript" charset="utf-8">
            $(document).ready(function(){
                $('#datatables').dataTable({
                    "sPaginationType":"full_numbers",
                    "aaSorting":[[2, "desc"]],
                    "bJQueryUI":true
                });
            })
        </script>

		<!-- Bootstrap core CSS -->
		<link href="../css/bootstrap.css" rel="stylesheet">
		<link href="../css3/bootstrap.min.css" rel="stylesheet">

		<!-- Custom styles for this template -->
		<link href="../css/justified-nav.css" rel="stylesheet">

		<!-- Just for debugging purposes. Don't actually copy this line! -->
		<!--[if lt IE 9]><script src="../js/ie8-responsive-file-warning.js"></script><![endif]-->

		<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
		<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
		<script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
		<![endif]-->
	</head>
	
	<body>
		<div class="container">
			<div class="row-fluid"><!--Container Navigasi-->
				<div class="masthead"><!--bagian Navigasi-->
					<div class="row-fluid">
						<div class="span9" style="margin-top: 50px;">
							<h1 class="text-muted"><b><? echo "Administrator Mey-Chatt"; ?></b></h1>
						</div>
						<div class="span3" align="right"><img src="../img/bot-c (4).jpg" alt="bot1" name="bot1" width="200px" height="200px"></img></div>
					</div>
					<hr>
					<div class="row-fluid">
						<div class="span8">
							<h5><?php echo "Anda login sebagai user <b style='color:blue;'>".$hasil['nama']."</b>"; ?></h5>
						</div>
						<div class="span4" align="right">
							<a href="index.php" class="btn btn-primary disable" type="button">Home</a>
							<a href="../index.php" class="btn btn-primary disable" type="button">Aplikasi</a>
							<a href="logout.php" class="btn btn-primary disable" type="button">Logout</a>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!--style="background-image:url(../img/girl.jpg); background-repeat:no-repeat;"-->
		<div class="container">
			<div class="row-fluid">
				<div class="span3">
					<div class="well">
						<a href="tambahdata.php" class="btn btn-block btn-primary disable" type="button">Tambah Q/A</a>
						<a href="editdata.php" class="btn btn-block btn-primary disable" type="button">Edit Q/A</a>
						<a href="viewlog.php" class="btn btn-block btn-primary disable" type="button">Lihat Log Q/A</a>
						<hr>
						<a href="daftar.php" class="btn btn-block btn-primary disable" type="button">Pengguna Baru</a>
					</div>
					<div>
						<img src="../img/bot-c (2).png" alt="bot1" name="bot1" width="300px" height="300px"></img>
					</div>
				</div>
				<div class="span9 well"><!-- sebelah sini yang di ubah ketika membuat halaman baru -->
					<h4>Perubahan & Update Data</h4>
					<p>
						Berikut ini dibawah adalah form editor user.
					</p>
						<!--bagian dimana php ini merupakan identitas berdasarkan rid yang di panggil oleh halaman edit.php  -->
						<?php
						$rid = $_GET['rid'];
						$query = mysql_query("select * from replies where rid='$rid'") or die(mysql_error());
						$data = mysql_fetch_array($query);
						?>
					<p>
						Silahkan Anda bisa merubah data pengguna atau user pada sesi berikut :
					</p>
					<form action="update.php" method="post">
						<input type="hidden" name="rid" value="<?php echo $rid; ?>" />
							<table>
								<tr>
									<td>Pertanyaan</td>
									<td>:</td>
									<td><input class="span12" type="text" name="trigger" maxlength="500" required="required" value="<?php echo $data['trigger']; ?>" /></td>
								</tr>
								<tr>
									<td>Jawaban</td>
									<td>:</td>
									<td><input class="span12" type="text" name="reply" maxlength="500" required="required" value="<?php echo $data['reply']; ?>" /></td>
								</tr>
								<tr>
									<td>Contribute User</td>
									<td>:</td>
									<td><input class="span12" class="span12" type="text" name="usercontrib" maxlength="10" required="required" value="<?php echo $data['usercontrib']; ?>" /></td>
								</tr>
								<tr>
									<td align="right" colspan="3"><input type="submit" name="submit" value="UBAH" class="btn btn-inverse"/></td>
									<td align="right" colspan="3"><a class="btn btn-danger" href="./editdata.php">BATAL</a></td>
								</tr>
							</table>
					</form>
				</div>
			</div>
			<hr>
			<div class="container" align="center" class="footer">
				<p>&copy; Company 2014 Smart Support By : <a href="mailto:meilitarahayu@gmail.com">Meilita Rahayu</a>.</p>
			</div>
		</div>
		
		<!-- Khusus konten javascript -->
		<!--<script src="../js/jquery-tab.js"></script>-->
		<script src="../js/jquery.js"></script>
		<script src="../js/jquery.dataTables.js"></script>
		<script src="../js/bootstrap-transition.js"></script>
		<script src="../js/bootstrap-alert.js"></script>
		<script src="../js/bootstrap-modal.js"></script>
		<script src="../js/bootstrap-dropdown.js"></script>
		<script src="../js/bootstrap-scrollspy.js"></script>
		<script src="../js/bootstrap-tab.js"></script>
		<script src="../js/bootstrap-tooltip.js"></script>
		<script src="../js/bootstrap-popover.js"></script>
		<script src="../js/bootstrap-button.js"></script>
		<script src="../js/bootstrap-collapse.js"></script>
		<script src="../js/bootstrap-carousel.js"></script>
		<script src="../js/bootstrap-typeahead.js"></script>
	</body>
</html>