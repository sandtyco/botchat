<?php

?>
<html>
<head>
<title>Smart Customer Support</title>
<!-- Bootstrap -->
<link href="css/bootstrap.css" rel="stylesheet" media="screen">
<!-- Custom styles for this template -->
<link href="css/jumbotron-narrow.css" rel="stylesheet">

<?php
// konfigurasi koneksi
if (file_exists("config.php")){
include("config.php");	
} else {
	$configured = "0";
}
if($configured != "1"){
echo 'Silahkan Anda lakukan <a href="setup.php">setup</a>.<br />Jika sudah Anda bisa seting <b>$configured</b> untuk memperbaiki file config.php.';
exit();
} else {


// Koneksi ke MySQL
$link = @mysql_connect($host, $username, $password)
   or die("<b>Maaf, koneksi database terputus.</b>");
   
// Memilih koneksi database yang benar
mysql_select_db($database);

// Memeriksa input koneksi, jika itu benar akan muncul pesan 'sudah terhubung'.
if (isset($_POST['msg'])) {
$usermessage = $_POST['msg'];
$default = FALSE;
} else {
$usermessage = 'sudah terhubung!';
$default = TRUE;
}

// Perintah memberi aturan untuk tidak memasukan tag html dalam input bot.
$htmlcharacters = array("<", ">", "&amp;", "&lt;", "&gt;", "&");
$usermessage = str_replace($htmlcharacters, "", $usermessage);

// Menghapus pesan dengan garis miring / slash.
$msg = stripslashes($usermessage);

// Memeriksa perintah message apakah benar atau tidak.
$isexpoint = $msg{0};

// Pernyataan filter symbol yang tidak ataupun yang boleh digunakan.
if ($isexpoint == "!"){
} else {
$badthings = array("=", "#", "~", "!", "?", ".", ",", "<", ">", "/", ";", ":", '"', "'", "[", "]", "{", "}", "@", "$", "%", "^", "&", "*", "(", ")", "-", "_", "+", "|", "`");
$msg = str_replace($badthings, "", $msg);
$msg = mb_strtolower($msg);
}

// Perintah untuk menterjemahkan istilah singkatan.
$contractions = array("yg", "hi", "dll", "dsb", "'d", "'re", "'ve", "i'm", "it's", "he's", "she's", "what's", "who's", " u ", " r ", " ur ", " im ");
$fullwords = array("yang", "hai", "dan lainnya", " dan sebagainya", " would", " are", " have", "i am", "it is", "he is", "she is", "what is", "who is", " you ", " are ", " you are ", " i am ");
$msg = str_replace($contractions, $fullwords, $msg);

// Perintah menghitung jumlah kata.
$msgarray = explode(" ", $msg);
$words = count($msgarray);

//Jika input adalah sebuah perintah, termasuk menu.php dan diluar database, maka perbandingan koneksi / string hanya biasa.
if ($isexpoint == "!" && $allowcommands == TRUE) {
include 'commands/menu.php';

// Mengatur posting, dan sistem penambahan balasan.
$command = 1;
} elseif ($isexpoint == "!" && $allowcommands == FALSE) {
$catbotreply = "Commands have been disabled.";
} else {

$command = 0;

// Pertama, memeriksa kata kedalam tabel database.
$equery = "SELECT * FROM `replies` WHERE `trigger` = '$msg';";
$exact = mysql_query($equery);
if(mysql_num_rows($exact) !== 0){
$result = $exact or die('Query failed: ' . mysql_error());
} else {

// Sisi untuk mencocokan triger.
$query = "SELECT *, MATCH (`trigger`) AGAINST ('$msg') AS score FROM `replies` WHERE MATCH (`trigger`) AGAINST ('$msg');";
$result = mysql_query($query) or die('Query failed: ' . mysql_error());
}
$replyarray = mysql_fetch_assoc($result);

if (isset($_POST['msg'])) {
$catbotreply = $replyarray['reply'];
} else {
$catbotreply = 'sudah terhubung!';
}

// Perintah mengisikan kata random saat tidak menemukan solusi jawaban.
$noreplyfound = array('...', 'Maaf', 'Ya', 'Hmmm', '???', 'Maaf?');

//Perintah jika tidak bisa menemukan salah satu text dalam database.
if($catbotreply == "" && $words == 1){
$catbotreply = ucfirst($msg) . "?";
} elseif($catbotreply == "") {
$catbotreply = $noreplyfound[rand(0,5)];
}

// Membatasi kata pertanyaan sebanyak 50 karakter.
if ($words > 50){
$catbotreply = "Ups! Maaf, ini bukan aplikasi Email, harap berikan pertanyaan singkat.";
}
}

//Perintah terakhir untuk membalas.
$simplecatbot = mb_strtolower($catbotreply);
$simplecatbot = str_replace($contractions, $fullwords, $simplecatbot);
$badthings = array("!", "?", ".", ",");
$simplecatbot = str_replace($badthings, "", $simplecatbot);

if (isset($_POST["lastcatbot"])){
$lastcatbot = $_POST["lastcatbot"];
}else{
$lastcatbot = "Connect!";
}

if(isset($_POST["lastwascomm"])){
$lastwascomm = $_POST["lastwascomm"];
}else{
$lastwascomm = 0;
}

if ($command == 0 && $lastwascomm == 0 && $default == FALSE){

$query = "SELECT * FROM `pending` WHERE `trigger` = '$lastcatbot' AND `reply` = '$usermessage';";
$result = mysql_query($query);
$alreadythere = mysql_fetch_assoc($result);
if ($alreadythere == FALSE){

$query = "INSERT INTO `pending` ( `trigger` , `reply` , `rnumber` ) VALUES ('$lastcatbot', '$usermessage', '1');";
mysql_query($query);

} else {

$query = "UPDATE `pending` SET rnumber=rnumber+1 WHERE `trigger` = '$lastcatbot';";
$result = mysql_query($query);

$query = "SELECT * FROM `pending` WHERE `rnumber` > 2;";
$result = mysql_query($query);
$overtwo = mysql_fetch_assoc($result);

if ($overtwo == FALSE){
} else {
$transfertrigger = $overtwo['trigger'];
$transferreply = $overtwo['reply'];
$rid = $overtwo['rid'];

$query = "INSERT INTO `replies` ( `trigger`, `reply`, `usercontrib` ) VALUES ('$transfertrigger', '$transferreply', '3');";
mysql_query($query);
$query = "DELETE FROM `pending` WHERE `rid` = '$rid';";
mysql_query($query);
}
}
}

//Memeriksa jika text bukan merupakan kata tercantum
if($logging == FALSE || $default == TRUE || $command == TRUE){
}else{

//Mendapatkan date & time
$timestamp = date('M j, Y g:i.s a');

//Mendapatkan keterangan IP berasal
$userip = $_SERVER["REMOTE_ADDR"];

//Define the log filename and the log entry.
$logentry = $timestamp . " --- " . $userip . " --- " . $msg . " --- " . $catbotreply . "\r\n";

//Membuka file log
$handle = fopen($logfile, 'ab');

//Menuliskan log entry
fwrite($handle, $logentry);
fclose($handle);
} 
}
?>
</head>

<body  class="container-narrow" onLoad="document.catbot.msg.focus()">
	<div align="center" class="logo">
		<a href="index.php"><img src="img/logo.png" width="299" height="118" alt="CatBot the Chatterbot"></a>
	</div>
	<hr>
	<div class="chatwindow">
		<div align="center">
			<form name="catbot" action="<?php echo($_SERVER["PHP_SELF"]); ?>" method="post">
				<b>Pesan:</b>
				<input type="text" name="msg" size="30" class="text">
				<input type="submit" name="submit" value="Kirim" class="btn btn-info disabled">
				<input type="hidden" name="lastcatbot" value="<?php echo $simplecatbot; ?>">
				<input type="hidden" name="lastwascomm" value="<?php echo $command; ?>">
			</form>

			<div>
				<b>Anda:</b> <?php echo stripslashes($usermessage); ?><br/><br/>
				<b>Support:</b> <?php echo $catbotreply;?><br/><br/>
			</div>
		</div>
	</div>
	<br/>
	<br/>
	<br/>
	<div align="center" class="copyrights">
		<p>Untuk lebih jelas mengenai detailnya, Anda bisa tanyakan ke Customer Support atau <a href="./admin/login.php">Admin</a> kami pada jam kerja, atau dengan mengirim <a href="mailto:sandtyco@gmail.com">mail ticket.</a></p>
	</div>

	<div align="center" class="footer">
		<p>&copy; Company 2014 Smart Support By : <a href="mailto:meilitarahayu@gmail.com">Meilita Rahayu</a>.</p>
	</div>
</body>
</html>