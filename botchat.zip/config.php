<?php
$host = 'localhost';$username = 'root';$password = '';$database = 'chatbot';$configured = 1;$logging = TRUE;$logfile = 'log.txt'; $allowcommands = TRUE;?>